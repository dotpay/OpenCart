OpenCart Dotpay payment module for Opencart 2.3.x
=====================
You can find module for older version OpenCart ( 2.0 - 2.2 ): https://github.com/dotpay/OpenCart/tree/Opencart-2.2

*English version below*

####Wtyczka dla OpenCart dodająca bramkę płatności Dotpay####

### Instrukcja: ###
1. Pobierz wtyczkę dotpay.zip (https://github.com/dotpay/OpenCart/releases/latest)
2. Wypakuj zawartość archiwum do głównego folderu OpenCart


---------------------------------------

####OpenCart plugin adding Dotpay payment gateway####

### Instructions: ###
1. Download the plugin dotpay.zip (https://github.com/dotpay/OpenCart/releases/latest)
2. Extract archive content to the main OpenCart folder